package com.gmmp.easylearn.model

data class Aula(var id: String, var titulo: String, var descricao: String,
                var thumbUrl: String, var duracao: String)