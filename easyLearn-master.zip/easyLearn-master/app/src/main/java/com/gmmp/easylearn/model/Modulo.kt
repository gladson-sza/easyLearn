package com.gmmp.easylearn.model

data class Modulo(var nome: String)