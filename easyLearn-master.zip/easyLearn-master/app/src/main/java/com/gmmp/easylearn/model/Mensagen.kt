package com.gmmp.easylearn.model

import java.util.*

data class Mensagen(var id: String, var titulo: String,
                    var descricao: String, var dataAtividade: Date)